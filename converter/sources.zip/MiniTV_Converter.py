import tkinter as tk
from tkinter import filedialog, messagebox
import os
import subprocess
try:
    from moviepy.editor import VideoFileClip
    MOVIEPY_INSTALLED = True
except ImportError:
    MOVIEPY_INSTALLED = False

    # Custom Font
custom_font = ("Helvetica", 18)

def execute_command(command):
    subprocess.run(command, shell=True)
    tk.messagebox.showinfo("Command Execution", "Command executed successfully!")

def execute_box_command(url):
    if url:
        command = f'yt-dlp.exe -S ext "{url}"'
        subprocess.run(command, shell=True)
        tk.messagebox.showinfo("Command Execution", "Command executed successfully!")

def extract_audio():
    input_file = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4")])
    if input_file:
        output_file = "44100.aac"
        volume_value = number_spinbox.get()  # Retrieve the value from the Spinbox
        command = f'ffmpeg -i "{input_file}" -vn -ar 44100 -ac 1 -ab 24k -af "loudnorm, volume={volume_value}dB" "{output_file}"'
        execute_command(command)

def convert_video():
    input_file = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4")])
    if input_file:
        output_file = "288_30fps.mjpeg"
        command = f'ffmpeg -i "{input_file}" -vf "fps=30,scale=288:-1:flags=lanczos,setsar=1:1,pad=288:240:(ow-iw)/2:(oh-ih)/2" -q:v 8 "{output_file}"'
        execute_command(command)

def execute_getmoviespy():
    try:
        subprocess.run(["pip", "install", "moviepy"], check=True)
        tk.messagebox.showinfo("Command Execution", "moviepy installed successfully! Please restart the application.")
    except subprocess.CalledProcessError:
        tk.messagebox.showerror("Error", "Failed to install moviepy. Please check your internet connection and try again.")
        
def crop_video():
    if not MOVIEPY_INSTALLED:
        tk.messagebox.showerror("Error", "moviepy is not installed. Please click the 'Install moviepy' button to install it.")
        return

    try:
        input_file = filedialog.askopenfilename(filetypes=[("Video Files", "*.mp4")])
        if input_file:
            output_file = "cropped.mp4"

            # Check video resolution using moviepy
            clip = VideoFileClip(input_file)
            width, height = clip.size
            clip.close()

            if width == 1920:  # If width is 1080p
                command = f'ffmpeg -i "{input_file}" -filter:v "crop=in_w-624:in_h" -preset ultrafast -c:a copy "{output_file}"'
            elif width == 1280:  # If width is 720p
                command = f'ffmpeg -i "{input_file}" -filter:v "crop=in_w-416:in_h" -preset ultrafast -c:a copy "{output_file}"'
            else:
                command = f'ffmpeg -i "{input_file}" -filter:v "crop=in_w-64:in_h" -preset ultrafast -c:a copy "{output_file}"'

            execute_command(command)
    except NameError:
        tk.messagebox.showerror("Error", "moviepy is not installed. Please install moviepy and restart the application.")
        return


# Create the main application window
root = tk.Tk()
root.title("Video Conversion")

# Set the size of the pop-up window
window_width = 600
window_height = 500
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width - window_width) // 2
y = (screen_height - window_height) // 2
root.geometry(f"{window_width}x{window_height}+{x}+{y}")

# Load the background image
background_image = tk.PhotoImage(file="background_image.png")

# Create a canvas to display the background image
canvas = tk.Canvas(root, width=window_width, height=100)
canvas.pack()
canvas.create_image(300, 0, anchor=tk.N, image=background_image)

# Add an input box to take URL input
url_entry_label = tk.Label(root, text="Enter YouTube URL:")
url_entry_label.pack(pady=10)
url_entry = tk.Entry(root)
url_entry.pack(pady=10)

# Add a button to trigger the command execution
execute_button = tk.Button(root, text="Download YoutTube Video", command=lambda: execute_box_command(url_entry.get()), bg="#D6002E", fg="white")
execute_button.pack(pady=10)

# Add a button to crop video
crop_button = tk.Button(root, text="Select Video to Crop", command=crop_video, bg="#8E008E", fg="white")
crop_button.pack(pady=10)

# Add a button to trigger the video conversion
convert_button = tk.Button(root, text="Select Video and Make Small", command=convert_video, bg="#006499", fg="white")
convert_button.pack(pady=10)

# Add a button to extract audio from a video
extract_audio_button = tk.Button(root, text="Select Video to Extract Audio", command=extract_audio, bg="#328E00", fg="white")
extract_audio_button.pack(pady=10)

# Add a Spinbox for the user to input a number between -8 to 8
number_label = tk.Label(root, text="Set Output Volume (-8db is DEFAULT) (-8dB to +8dB):")
number_label.pack(pady=6)
number_spinbox = tk.Spinbox(root, from_=-8, to=8)
number_spinbox = tk.Spinbox(root, from_=-8, to=8, width=5, font=custom_font)
number_spinbox.pack(pady=6)

# Start the GUI event loop
root.mainloop()
